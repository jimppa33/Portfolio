#include <iostream>

std::string playerChoiceStr;
std::string computerChoiceStr;

char getUserchoice();
char getComputerChoice();
std::string getWinner(char playerChoice, char computerChoice);

int main()
{
    do
    {
        char playerChoice = getUserchoice();
        char computerChoice = getComputerChoice();
        std::string gameResult = getWinner(playerChoice, computerChoice);

        std::cout << "\nYour choice: " << playerChoiceStr << std::endl;
        std::cout << "Computer choice: " << computerChoiceStr << std::endl;
        std::cout << gameResult << std::endl;
        std::cout << std::endl;
    } while (true);

    return 0;
}

char getUserchoice()
{
    char playerChoice;

    std::cout << "r = Rock\np = Paper\ns = Scissors\n";
    std::cout << "Enter your choice: ";

    std::cin >> playerChoice;

    if (playerChoice == 'r' || playerChoice == 'R')
    {
        playerChoiceStr = "Rock";
        return playerChoice;
    }
    else if (playerChoice == 'p' || playerChoice == 'P')
    {
        playerChoiceStr = "Paper";
        return playerChoice;
    }
    else if (playerChoice == 's' || playerChoice == 'S')
    {
        playerChoiceStr = "Scissors";
        return playerChoice;
    }
    else
    {
        std::cout << "\nINVALID CHARACTER!!\n";
        std::cout << std::endl;
        getUserchoice();
        return 0;
    }
}

char getComputerChoice()
{
    char computerChoice;
    int choiceNum = rand() % 3 + 1;

    switch (choiceNum)
    {
    case 1:
        computerChoiceStr = "Rock";
        computerChoice = 'r';
        break;
    case 2:
        computerChoiceStr = "Paper";
        computerChoice = 'p';
        break;
    case 3:
        computerChoiceStr = "Scissors";
        computerChoice = 's';
        break;
    }

    return computerChoice;
}

std::string getWinner(char playerChoice, char computerChoice)
{
    std::string gameResult;
    std::string win = "YOU WIN!!";
    std::string lose = "YOU LOSE!!";

    if (playerChoice == 'r' && computerChoice == 'p' || playerChoice == 'R' && computerChoice == 'p')
    {
        gameResult = lose;
    }
    else if (playerChoice == 'r' && computerChoice == 's' || playerChoice == 'R' && computerChoice == 's')
    {
        gameResult = win;
    }
    else if (playerChoice == 'p' && computerChoice == 'r' || playerChoice == 'P' && computerChoice == 'r')
    {
        gameResult = win;
    }
    else if (playerChoice == 'p' && computerChoice == 's' || playerChoice == 'P' && computerChoice == 's')
    {
        gameResult = lose;
    }
    else if (playerChoice == 's' && computerChoice == 'p' || playerChoice == 'S' && computerChoice == 'p')
    {
        gameResult = win;
    }
    else if (playerChoice == 's' && computerChoice == 'r' || playerChoice == 'S' && computerChoice == 'r')
    {
        gameResult = lose;
    }
    else
    {
        gameResult = "DEUCE!!";
    }

    return gameResult;
}