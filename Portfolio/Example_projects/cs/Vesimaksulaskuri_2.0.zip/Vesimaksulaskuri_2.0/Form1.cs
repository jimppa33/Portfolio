﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Vesimaksulaskuri_2._0
{
    public partial class Form1 : Form
    {
        DateTime muutosaika, tallennusaika, avausaika, kaynnistysaika;
        string tiedostonimi = "@\"C:\\Users\\asus\\Documents\\Vesimittarilukemat.txt\""; 
        public Form1()
        {
            InitializeComponent();
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.ReadOnly = true;
            textBox9.ReadOnly = true;
            textBox9.Enabled = false;
            textBox4.ReadOnly = true;
            textBox8.Enabled = false;
            textBox4.Enabled = false;
            textBox8.ReadOnly = true;
            textBox3.Text = "5,00";
            textBox7.Text = "10,00";
            textBox10.Text = DateTime.Today.ToShortDateString().ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("Syötä uusi vesimittarin lukema (kylmä)");

            else if (textBox2.Text == "")
                MessageBox.Show("Syötä edellinen vesimittarin lukema (kylmä)");

            else if (textBox5.Text == "")
                MessageBox.Show("Syötä uusi vesimittarin lukema (kuuma)");

            else if (textBox6.Text == "")
                MessageBox.Show("Syötä edellinen vesimittarin lukema (kylmä)");

            else
            {
                double mittarilukemaNytKylma = int.Parse(textBox1.Text);
                double mittarilukemaViimeksiKylma = int.Parse(textBox2.Text);
                double mittarilukemaNytKuuma = int.Parse(textBox5.Text);
                double mittarilukemaViimeksiKuuma = int.Parse(textBox6.Text);
                double hintaKylma = double.Parse(textBox3.Text);
                double hintaKuuma = double.Parse(textBox7.Text);

                double kulutusKylma = mittarilukemaNytKylma - mittarilukemaViimeksiKylma;
                double kulutusKuuma = mittarilukemaNytKuuma - mittarilukemaViimeksiKuuma;

                double kylmaOsuus = (mittarilukemaNytKylma - mittarilukemaViimeksiKylma) / 1000 * hintaKylma;
                double kuumaOsuus = (mittarilukemaNytKuuma - mittarilukemaViimeksiKuuma) / 1000 * hintaKuuma;

                double kokonaishinta = kylmaOsuus + kuumaOsuus;

                textBox9.Text = kokonaishinta.ToString("F2");
                textBox4.Text = kylmaOsuus.ToString("F2") + " €";
                textBox8.Text = kuumaOsuus.ToString("F2") + " €";

                dataGridView1.Rows.Add(dataGridView1.Rows.Count + 1, textBox10.Text, mittarilukemaNytKylma + " (" + kulutusKylma + ")", mittarilukemaNytKuuma + " (" + kulutusKuuma + ")", kokonaishinta.ToString("F2"));
            }
        }

        private void tyhjennäToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox8.Clear();
            textBox9.Clear();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (tallennusaika < muutosaika && muutosaika > kaynnistysaika && avausaika < muutosaika)
            {
                MessageBoxButtons mb = MessageBoxButtons.YesNoCancel;
                var result = MessageBox.Show("Haluatko tallentaa tiedoston?", "", mb);

                if (result == DialogResult.Yes)
                    tallennaNimelläToolStripMenuItem_Click(sender, e);

                else if (result == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }

        private void avaaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (muutosaika > kaynnistysaika && muutosaika > tallennusaika && muutosaika > avausaika)
            {
                var result = MessageBox.Show("Tallennetaanko taulukossa olevat tiedot?", "", MessageBoxButtons.YesNoCancel);

                if (result == DialogResult.No)
                {
                    OpenFileDialog ofd = new OpenFileDialog();

                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        dataGridView1.Rows.Clear();

                        string[] lines = File.ReadAllLines(ofd.FileName);
                        string[] data;

                        for (int i = 0; i < lines.Length; i++)
                        {
                            data = lines[i].ToString().Split('|');

                            string[] row = new string[data.Length];

                            for (int j = 0; j < data.Length; j++)
                            {
                                row[j] = data[j].Trim();
                            }

                            dataGridView1.Rows.Add(row);
                        }

                        avausaika = DateTime.Now;
                        tabPage2.Text = "Mittarilukemataulukko";
                        MessageBox.Show("Tiedosto avattu");
                        tiedostonimi = ofd.FileName;
                    }
                }

                else if (result == DialogResult.Yes)
                {
                    tallennaNimelläToolStripMenuItem_Click(sender, e);

                    OpenFileDialog ofd = new OpenFileDialog();

                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        dataGridView1.Rows.Clear();

                        string[] lines = File.ReadAllLines(ofd.FileName);
                        string[] data;

                        for (int i = 0; i < lines.Length; i++)
                        {
                            data = lines[i].ToString().Split('|');

                            string[] row = new string[data.Length];

                            for (int j = 0; j < data.Length; j++)
                            {
                                row[j] = data[j].Trim();
                            }

                            dataGridView1.Rows.Add(row);
                        }

                        avausaika = DateTime.Now;
                        tabPage2.Text = "Mittarilukemataulukko";
                        MessageBox.Show("Tiedosto avattu");
                        tiedostonimi = ofd.FileName;
                    }
                }
            }

            else
            {
                OpenFileDialog ofd = new OpenFileDialog();

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    dataGridView1.Rows.Clear();

                    string[] lines = File.ReadAllLines(ofd.FileName);
                    string[] data;

                    for (int i = 0; i < lines.Length; i++)
                    {
                        data = lines[i].ToString().Split('|');

                        string[] row = new string[data.Length];

                        for (int j = 0; j < data.Length; j++)
                        {
                            row[j] = data[j].Trim();
                        }

                        dataGridView1.Rows.Add(row);
                    }

                    avausaika = DateTime.Now;
                    tabPage2.Text = "Mittarilukemataulukko";
                    MessageBox.Show("Tiedosto avattu");
                    tiedostonimi = ofd.FileName;
                }
            }
        }

        private void otaLukematToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in dataGridView1.SelectedRows)
            {
             textBox2.Text = dataGridView1.Rows[item.Index].Cells[2].Value.ToString();
             textBox6.Text = dataGridView1.Rows[item.Index].Cells[3].Value.ToString();
            }
        }

        private void poistaRiviToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in dataGridView1.SelectedRows)
            {
                dataGridView1.Rows.RemoveAt(item.Index);
            }
        }

        private void päivitäRiviToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("Syötä uusi vesimittarin lukema (kylmä)");

            else if (textBox2.Text == "")
                MessageBox.Show("Syötä edellinen vesimittarin lukema (kylmä)");

            else if (textBox5.Text == "")
                MessageBox.Show("Syötä uusi vesimittarin lukema (kuuma)");

            else if (textBox6.Text == "")
                MessageBox.Show("Syötä edellinen vesimittarin lukema (kylmä)");

            else
            {
                int mittarilukemaNytKylma = int.Parse(textBox1.Text);
                int mittarilukemaViimeksiKylma = int.Parse(textBox2.Text);
                int mittarilukemaNytKuuma = int.Parse(textBox5.Text);
                int mittarilukemaViimeksiKuuma = int.Parse(textBox6.Text);
                double hintaKylma = double.Parse(textBox3.Text);
                double hintaKuuma = double.Parse(textBox7.Text);

                double kylmaOsuus = (mittarilukemaNytKylma - mittarilukemaViimeksiKylma) / 1000 * hintaKylma;
                double kuumaOsuus = (mittarilukemaNytKuuma - mittarilukemaViimeksiKuuma) / 1000 * hintaKuuma;

                double kokonaishinta = kylmaOsuus + kuumaOsuus;

                textBox9.Text = kokonaishinta.ToString("F2");
                textBox4.Text = kylmaOsuus.ToString("F2") + " €";
                textBox8.Text = kuumaOsuus.ToString("F2") + " €";

                foreach (DataGridViewRow item in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows[item.Index].Cells[1].Value = textBox10.Text;
                    dataGridView1.Rows[item.Index].Cells[2].Value = textBox1.Text;
                    dataGridView1.Rows[item.Index].Cells[3].Value = textBox5.Text;
                    dataGridView1.Rows[item.Index].Cells[4].Value = textBox9.Text;
                }
            } 
        }

        private void dataGridView1_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            muutosaika =DateTime.Now;

            if (muutosaika > kaynnistysaika && muutosaika > avausaika && muutosaika > tallennusaika) tabPage2.Text = "Mittarilukemataulukko*";
        }

        private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            muutosaika = DateTime.Now;

            if (muutosaika > kaynnistysaika && muutosaika > avausaika && muutosaika > tallennusaika) tabPage2.Text = "Mittarilukemataulukko*";
        }

        private void tabControl1_KeyDown(object sender, KeyEventArgs e)
        {
            
            if (e.Control == true && e.KeyCode == Keys.S)
                    tallennaNimelläToolStripMenuItem_Click(sender, e);

            else if (e.Control == true && e.KeyCode == Keys.O)
                    avaaToolStripMenuItem_Click(sender, e);

            else if (e.Control == true && e.KeyCode == Keys.R)
                    tyhjennäToolStripMenuItem_Click(sender, e);
          
                
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            muutosaika =DateTime.Now;

            if (muutosaika > kaynnistysaika && muutosaika > avausaika && muutosaika > tallennusaika) tabPage2.Text = "Mittarilukemataulukko*";
        }

        private void tallennaNimelläToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.FileName = ".txt";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(sfd.FileName);

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if (j == dataGridView1.Columns.Count - 1)
                            sw.Write("\t" + dataGridView1.Rows[i].Cells[j].Value.ToString());

                        else sw.Write("\t" + dataGridView1.Rows[i].Cells[j].Value.ToString() + "\t" + "|");
                    }
                    sw.WriteLine("");
                }
                sw.Close();

                tallennusaika = DateTime.Now;
                tabPage2.Text = "Mittarilukemataulukko";
                MessageBox.Show("Tiedosto tallennettu");
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            otaLukematToolStripMenuItem_Click(sender, e);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"C:\Users\asus\Documents\Vesimittarilukemat.txt");
            string[] data;

            for (int i = 0; i < lines.Length; i++)
            {
                data = lines[i].ToString().Split('|');

                string[] row = new string[data.Length];

                for (int j = 0; j < data.Length; j++)
                {
                    row[j] = data[j].Trim();
                }

                dataGridView1.Rows.Add(row);
            }

            kaynnistysaika = DateTime.Now;
            tabPage2.Text = "Mittarilukemataulukko";
        }
    }
}
