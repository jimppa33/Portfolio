const canvas = document.getElementById("renderCanvas"); // Get the canvas element
const engine = new BABYLON.Engine(canvas, true); // Generate the BABYLON 3D engine

const yPos = document.getElementById("ypos")

const createScene = function () {

    const scene = new BABYLON.Scene(engine);

    const camera = new BABYLON.FreeCamera("camera1",
        new BABYLON.Vector3(0, 6, 10),
        scene);

    camera.setTarget(BABYLON.Vector3.Zero());

    const light = new BABYLON.HemisphericLight("light",
        new BABYLON.Vector3(0, 1, 0),
        scene);

    light.intensity = 0.7;

    var cylinder = BABYLON.MeshBuilder.CreateCylinder("cylinder", { height: 2, diameter: 1, tessellation: 50 }, scene);

    let cylPosY = 3
    cylinder.position.y = cylPosY;
    let cylPosX = 0
    cylinder.position.x = cylPosX

    const torus = BABYLON.MeshBuilder.CreateTorus("torus", { diameter: 2.4, thickness: 0.8, tessellation: 50 }, scene);
    torus.position.y = -3

    let slideAnim
    const frameRate = 10;
    let speed = 0.2

    let score = 0
    let hScore = 0


    let scoreBoard = document.createElement("div");
    scoreBoard.style.top = "45%";
    scoreBoard.style.left = "90px";
    scoreBoard.style.width = "150px"
    scoreBoard.style.height = "100px"
    scoreBoard.style.fontSize = "30px"
    scoreBoard.setAttribute = ("id", "scoreB");
    scoreBoard.style.position = "absolute";
    scoreBoard.style.color = "white";
    document.body.appendChild(scoreBoard);


    let hsBoard = document.createElement("div");
    hsBoard.style.top = "55%";
    hsBoard.style.left = "90px";
    hsBoard.style.width = "300px"
    hsBoard.style.height = "100px"
    hsBoard.innerHTML = "HIGH SCORE: 0"
    hsBoard.style.fontSize = "30px"
    hsBoard.setAttribute = ("id", "hsBoard");
    hsBoard.style.position = "absolute";
    hsBoard.style.color = "white";
    document.body.appendChild(hsBoard);



    let htpTxt = document.createElement("div");
    htpTxt.style.top = "45%";
    htpTxt.style.left = "36%";
    htpTxt.style.width = "600px"
    htpTxt.style.height = "100px"
    htpTxt.style.fontSize = "30px"
    htpTxt.innerHTML = "Press SPACE to try to get in hole"
    htpTxt.setAttribute = ("id", "scoreB");
    htpTxt.style.position = "absolute";
    htpTxt.style.color = "white";
    document.body.appendChild(htpTxt);



    document.onload = slide(), updateScore(), getHighScore()

    function slide() {

        const xSlide = new BABYLON.Animation("xSlide", "position.x", frameRate, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE);

        const keyFrames = [];

        keyFrames.push({
            frame: 0,
            value: 6
        });

        keyFrames.push({
            frame: frameRate,
            value: -6
        });

        keyFrames.push({
            frame: 2 * frameRate,
            value: 6
        });

        xSlide.setKeys(keyFrames);

        cylinder.animations.push(xSlide);

        slideAnim = scene.beginDirectAnimation(cylinder, [xSlide], 0, 2 * frameRate, true, speed);
    }

    let yFailPos = -1.5
    let ySuccesPos = -5

    function updateScore() {
        scoreBoard.innerHTML = `SCORE: ${score}`
    }

    function setHighScore() {
        if (score >= hScore) {
            hScore = score
            hsBoard.innerHTML = `HIGH SCORE: ${hScore}`

            localStorage.setItem("highScore", hScore)
        }
    }

    function getHighScore() {
        hScore = localStorage.getItem("highScore")
        hsBoard.innerHTML = `HIGH SCORE: ${hScore}`
    }

    function removeHTP() {
        htpTxt.innerHTML = ""
    }

    function timeoutFunc() {
        if (cylinder.absolutePosition.y === yFailPos) {
            htpTxt.style.top = "80px"
            htpTxt.style.left = "34%"
            htpTxt.innerHTML = "GAME OVER!\nPress SPACE to restart"
        }
        else if (cylinder.absolutePosition.y === ySuccesPos) {
            updateScore()
            setHighScore()
            cylinder.position.y = cylPosY
            slide()
        }
    }

    document.addEventListener("keydown", (e) => {
        if (e.key === " " && cylinder.absolutePosition.y > yFailPos) {
            setTimeout(timeoutFunc, 1200)
            removeHTP()
            slideAnim.pause()
            goDown()
        }
        else if (e.key === " " && cylinder.absolutePosition.y === yFailPos) {
            score = 0
            updateScore()
            removeHTP()
            cylinder.position.y = cylPosY
            slide()
        }
    })

    function goDown() {
        cylPosX = cylinder.absolutePosition.x

        const startFrame = 0;
        const endFrame = 10;

        const ySlide = new BABYLON.Animation("ySlide", "position.y", frameRate, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE);

        const keyFrames = [];

        if (cylPosX >= -0.25 && cylPosX <= 0.25) {


            keyFrames.push({
                frame: startFrame,
                value: 5
            });

            keyFrames.push({
                frame: endFrame,
                value: ySuccesPos
            });


            ySlide.setKeys(keyFrames);

            cylinder.animations.push(ySlide);

            scene.beginDirectAnimation(cylinder, [ySlide], startFrame, endFrame, false, 1);

            speed += 0.05

            score++
        }
        else {


            keyFrames.push({
                frame: startFrame,
                value: 1
            });

            keyFrames.push({
                frame: endFrame,
                value: yFailPos
            });


            ySlide.setKeys(keyFrames);

            cylinder.animations.push(ySlide);

            scene.beginDirectAnimation(cylinder, [ySlide], startFrame, endFrame, false, 1);

            speed = 0.2
        }



    }

    return scene;
};

const scene = createScene(); //Call the createScene function

// Register a render loop to repeatedly render the scene
engine.runRenderLoop(function () {
    scene.render();
});

// Watch for browser/canvas resize events
window.addEventListener("resize", function () {
    engine.resize();
});