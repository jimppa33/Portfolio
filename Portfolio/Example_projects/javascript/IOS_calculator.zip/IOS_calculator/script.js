const nums = document.querySelectorAll('.nums')
const operators = document.querySelectorAll('.operator')
const result = document.querySelector('.result')
const clearBtn = document.querySelector('#clear')
const negativeBtn = document.querySelector('#negative')
const percentBtn = document.querySelector('#percent')
const commaBtn = document.querySelector('#comma')
const equal = document.querySelector('#equal')

let isFirstValue = true
let isSecondValue = false
let firstValue = ''
let secondValue = ''
let resValue = ''
let operator = ''
let commaCount = 0

function getNumber(){
    for (let i = 0; i < nums.length; i++) {
        nums[i].addEventListener('click', (e) =>{
            let number = e.target.getAttribute('value')
        
            if(isFirstValue == true) getFirstValue(number)
            else if(isSecondValue == true) getSecondValue(number)
        })
    }
}

function getOpearator(){
    for (let i = 0; i < operators.length; i++) {
        operators[i].addEventListener('click', (e) =>{
            isFirstValue = false
            isSecondValue = true
            operator = e.target.getAttribute('value')
            commaCount = 0
        })
    }
}

function getFirstValue(firstNumberElement){
    firstValue += firstNumberElement
    result.innerText = firstValue
    firstValue = +firstValue
}

function getSecondValue(secondNumberElement){
    secondValue += secondNumberElement
    result.innerText = secondValue
    secondValue = +secondValue
}

function calculate(){
    equal.addEventListener('click', () =>{
        if(firstValue == '') firstValue = 0
        if(secondValue == '') secondValue = firstValue
        
        if(operator == 'divide') resValue = firstValue / secondValue
        else if(operator == 'times') resValue = firstValue * secondValue
        else if(operator == 'minus') resValue = firstValue - secondValue
        else if(operator == 'plus') resValue = firstValue + secondValue
        
        result.innerText = resValue
        firstValue = resValue
        secondValue = ''
        commaCount = 0

        checkResultLenght()
    })
}

function clear(){
    clearBtn.addEventListener('click', () =>{
        isFirstValue = true
        isSecondValue = false
        firstValue = ''
        secondValue = ''
        resValue = ''
        operator = ''
        result.innerText = 0
        commaCount = 0
    })
}

function negative(){
    negativeBtn.addEventListener('click', () =>{
        if(isFirstValue == true && firstValue != ''){
            firstValue = -firstValue
            result.innerText = firstValue
        }
        else if(isSecondValue == true && secondValue != ''){
            secondValue = -secondValue
            result.innerText = secondValue
        }
    })
}

function percent(){
    percentBtn.addEventListener('click', () =>{
        if(isFirstValue == true && firstValue != ''){
            firstValue = firstValue / 100
            result.innerText = firstValue
        }
        else if(isSecondValue == true && secondValue != ''){
            if(operator == 'divide' || operator == 'times'){
                secondValue = secondValue / 100
                result.innerText = secondValue
            }
            else if(operator == 'plus' || operator == 'minus'){
                secondValue = firstValue * secondValue / 100
                result.innerText = secondValue
            }
        }
    })
}

function comma(){
    commaBtn.addEventListener('click', () =>{
        commaCount++
        if(commaCount == 1){
            if(isFirstValue == true){
                firstValue += '.'
                result.innerText = firstValue
            }
            else if(isSecondValue == true){
                secondValue += '.'
                result.innerText = secondValue
            }
        }
    })
}

function checkResultLenght(){
    resValue = resValue.toString()

    if(resValue.length >= 8){
        resValue = parseFloat(resValue)
        result.innerText = resValue.toFixed(4)
    }
}

getOpearator()
getNumber()
calculate()
clear()
negative()
percent()
comma()