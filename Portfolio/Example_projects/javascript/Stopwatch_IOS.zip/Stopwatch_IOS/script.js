const minutes = document.querySelector('.minutes')
const seconds = document.querySelector('.seconds')
const milliseconds = document.querySelector('.milliseconds')

const lapBtn = document.querySelector('.lap')
const startBtn = document.querySelector('.start')

const lap = document.querySelector('.laps')

let timerStarted = false
let int = null
let ms = 0
let s = 0
let m = 0
let msLapTime = 0
let sLapTime = 0
let mLapTime = 0
let lapNumber = 0
let lapTime = 0
let resetNumber = 0
let lapArr = []

startBtn.addEventListener('click', () =>{
    if(timerStarted == false){
        int = setInterval(timerOn, 10)
        timerStarted = true

        startBtn.innerHTML = 'Pysäytä'
        startBtn.style.color = 'red'
        startBtn.style.backgroundColor = 'darkred'

        lapBtn.innerHTML = 'Kierros'
    }
    else{
        clearInterval(int)
        timerStarted = false
    
        startBtn.innerHTML = 'Aloita'
        startBtn.style.color = 'lightgreen'
        startBtn.style.backgroundColor = 'darkgreen'

        lapBtn.innerHTML = 'Nollaa'
    }
})

function timerOn(){
    ms ++
    
    if(ms >= 99){
        s ++
        ms = 0
    }
    if(s >= 60){
        m ++
        s = 0
    }

    if(ms < 10) milliseconds.innerHTML = '0' + ms
    else milliseconds.innerHTML = ms

    if(s < 10) seconds.innerHTML = '0' + s + ','
    else seconds.innerHTML = s + ','

    if(m < 10) minutes.innerHTML = '0' + m + '.'
    else minutes.innerHTML = m + '.'
}

lapBtn.addEventListener('click', () =>{
    if(timerStarted == true && lapBtn.innerHTML == 'Kierros'){
        lapNumber ++
        resetNumber ++

        if(ms < 10) msLapTime = '0' + ms
        else msLapTime = ms

        if(s < 10) sLapTime = '0' + s + ','
        else sLapTime = s + ','

        if(m < 10) mLapTime = '0' + m + '.'
        else mLapTime = m + '.'

        lapTime = mLapTime + sLapTime + msLapTime

        lapArr.unshift(
            `<div class="lapRow">
                <span>Kierros ${lapNumber}</span>
                <span>${lapTime}</span>
            </div>`
        )

        lap.innerHTML = lapArr
        
    }
    else if(timerStarted == false && lapBtn.innerHTML == 'Nollaa'){
        minutes.innerHTML = '00.'
        seconds.innerHTML = '00,'
        milliseconds.innerHTML = '00'
        lap.innerHTML = ''
        lapNumber = 0
        lapArr = []
        ms = 0
        s = 0
        m = 0
    }
})