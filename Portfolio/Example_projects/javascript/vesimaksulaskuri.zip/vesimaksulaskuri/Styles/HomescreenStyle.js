import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        width: '100%',
        backgroundColor: '#fff',
        display: 'flex',
        flexDirection: 'column',
    },

    textinput_kylmä: {
        borderWidth: 2,
        borderColor: 'blue',
        margin: 10,
        width: 150,
        borderRadius: 5,
    },

    textinput_kuuma: {
        borderWidth: 2,
        borderColor: 'red',
        margin: 10,
        width: 150,
        borderRadius: 5,
    },

    container_textinput: {
        marginTop: 100,
    },

    container_textinputs: {
        width: '100%',
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center'
    },

    text_kylmä: {
        fontSize: 20,
        marginLeft: 50,
        color: 'blue',
    },

    text_lämmin: {
        fontSize: 20,
        marginLeft: 40,
        color: 'red',
    },
});

export default styles