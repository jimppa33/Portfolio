import React from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import styles from '../Styles/HomescreenStyle';

function Homescreen() {

    let [previousCold, changePreviousCold] = React.useState('')
    let [previousWarm, changePreviousWarm] = React.useState('')
    let [newCold, changeNewCold] = React.useState('')
    let [newWarm, changeNewWarm] = React.useState('')
    let [prizeCold, changePrizeCold] = React.useState('')
    let [prizeWarm, changePrizeWarm] = React.useState('')

    function Calc() {
        if (previousCold != '' && previousWarm != '' && newCold != '' && newWarm != '' && prizeCold != '' && prizeWarm != '') {
            const previousColdToNum = Number.parseFloat(previousCold)
            const previousWarmToNum = Number.parseFloat(previousWarm)
            const newColdToNum = Number.parseFloat(newCold)
            const newWarmToNum = Number.parseFloat(newWarm)
            const prizeColdToNum = Number.parseFloat(prizeCold)
            const prizeWarmToNum = Number.parseFloat(prizeWarm)

            const result = (newColdToNum - previousColdToNum) / 1000 * prizeColdToNum + (newWarmToNum - previousWarmToNum) / 1000 * prizeWarmToNum
            const totalColdPrize = (newColdToNum - previousColdToNum) / 1000 * prizeColdToNum
            const totalColdUsage = newColdToNum - previousColdToNum
            const totalWarmPrize = (newWarmToNum - previousWarmToNum) / 1000 * prizeWarmToNum
            const totalWarmUsage = newWarmToNum - previousWarmToNum

            Alert.alert('', `Hinta: ${result.toFixed(2)}€
            Kylmä: ${totalColdPrize.toFixed(2)}€ (${totalColdUsage.toFixed(0)} l)
            Lämmin: ${totalWarmPrize.toFixed(2)}€ (${totalWarmUsage.toFixed(0)} l)`)
        }
        else Alert.alert('Huomio!', 'Täytä puuttuvat kentät!')
    }

    function Clear() {
        this.textInput.clear()
        this.textInput2.clear()
        this.textInput3.clear()
        this.textInput4.clear()
        this.textInput5.clear()
        this.textInput6.clear()

        previousCold = ""
        previousWarm = ""
        newCold = ""
        newWarm = ""
        prizeCold = ""
        prizeWarm = ""
    }

    return (
        <View style={styles.container}>

            <View style={styles.container_textinputs}>
                <View style={styles.container_textinput}>
                    <Text style={styles.text_kylmä}>Kylmä</Text>
                    <TextInput style={styles.textinput_kylmä} ref={input => { this.textInput = input }} clearButtonMode='while-editing' placeholder="Edellinen lukema" keyboardType='numeric' onChangeText={changePreviousCold}></TextInput>
                    <TextInput style={styles.textinput_kylmä} ref={input => { this.textInput2 = input }} clearButtonMode='while-editing' placeholder="Uusi lukema" keyboardType='numeric' onChangeText={changeNewCold}></TextInput>
                    <TextInput style={styles.textinput_kylmä} ref={input => { this.textInput3 = input }} clearButtonMode='while-editing' placeholder='Hinta' keyboardType='numeric' onChangeText={changePrizeCold}></TextInput>
                    <Button color={'black'} title='Laske' onPress={Calc} clearButtonMode='while-editing'></Button>
                </View>

                <View style={styles.container_textinput}>
                    <Text style={styles.text_lämmin}>Lämmin</Text>
                    <TextInput id='previousWarm' style={styles.textinput_kuuma} ref={input => { this.textInput4 = input }} clearButtonMode='while-editing' placeholder="Edellinen lukema" keyboardType='numeric' onChangeText={changePreviousWarm}></TextInput>
                    <TextInput id='newWarm' style={styles.textinput_kuuma} ref={input => { this.textInput5 = input }} clearButtonMode='while-editing' placeholder="Uusi lukema" keyboardType='numeric' onChangeText={changeNewWarm}></TextInput>
                    <TextInput id='prizeWarm' style={styles.textinput_kuuma} ref={input => { this.textInput6 = input }} clearButtonMode='while-editing' placeholder='Hinta' keyboardType='numeric' onChangeText={changePrizeWarm}></TextInput>
                    <Button color={'black'} title='Tyhjennä' onPress={Clear} clearButtonMode='while-editing'></Button>
                </View>
            </View>

        </View>
    );
}

export default Homescreen;