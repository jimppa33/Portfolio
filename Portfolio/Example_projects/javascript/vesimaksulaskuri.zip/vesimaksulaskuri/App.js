import Homescreen from './Screens/Homescreen';

export default function App() {

  return (
    <Homescreen></Homescreen>
  );
}

